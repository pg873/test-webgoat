package org.owasp.webgoat.util;

public class LabelManagerImplTest {

//    @Test
//    public void shouldSerialize() throws IOException {
//        LabelManagerImpl labelManager = new LabelManagerImpl(null, new LabelDebugger());
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        ObjectOutputStream out = new ObjectOutputStream(bos);
//        out.writeObject(labelManager);
//    }
//
//    @Test
//    public void shouldSerializeWithLabelProvider() throws IOException {
//        LabelManagerImpl labelManager = new LabelManagerImpl(new LabelProvider(), new LabelDebugger());
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        ObjectOutputStream out = new ObjectOutputStream(bos);
//        out.writeObject(labelManager);
//    }
}