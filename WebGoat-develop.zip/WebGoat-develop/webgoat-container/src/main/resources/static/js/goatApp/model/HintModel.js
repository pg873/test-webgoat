define(['jquery',
	'underscore',
	'backbone'],
	function($,
		_,
		Backbone,
		HTMLContentModel) {
	return Backbone.Model.extend({
	});
});